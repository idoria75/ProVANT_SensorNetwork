#include "data.h"
#include "debug.h"
#include <FS.h>

File f;

int open_once = 1;
long i =1;


Data::Data() :
    data(new dataStruct)
{
    debug("Starting Data.");
    print();
}

void Data::jsonSet(const char* key, const char* value)
{
    root[0][key] = value;
}

void Data::updateJson()
{
    StaticJsonBuffer<1024> jsonBuffer;
    root = &jsonBuffer.createObject();
    jsonSet("Sensor", data->hostName.c_str());

    JsonArray& gpsJson = root->createNestedArray("gps");
    gpsJson.add(double_with_n_digits(data->upTime, 7));
    gpsJson.add(double_with_n_digits(data->lat, 7));
    gpsJson.add(double_with_n_digits(data->lon, 7));

}

void Data::updateJson(char * msg){
    StaticJsonBuffer<1024> jsonBuffer;
    DynamicJsonBuffer jsonBuffer2;
    //debug("%s", msg.c_str());
    //debug("%s", msg.c_str());

    //[TESTING ONLY]
    //char buf[100];
    debug("MESSAGE RECEIVED: %s", msg);
    //msg.toCharArray(buf,100);
    JsonObject& root2 = jsonBuffer2.parseObject(msg); 
    
  //  root = &jsonBuffer.parseObject(msg);
    //debug("PRETTY PRINT TO:");
    //jsonBuffer2->prettyPrintTo(Serial);
    //debug("STRING MODE");
    //debug("%s", root[0]["sensor"][0].as<float>());
    String teste;
    String patrick;
    root2.printTo(teste);
    if(root2.success()){
        debug("SUCCESS");

        const char * sensor = root2["sensor"];
        long time_a = root2["time"];
        //float lat = root2["data"][0];
        //JULIANO CHANGINGS 10/04/17
        double lat = (double)root2["data"][0];
        double lon = (double)root2["data"][1];


        // open file for writing
        //File f = SPIFFS.open("/f.txt", "w");
        //if (open_once){
            f = SPIFFS.open("/f.txt", "a");
            if (!f) {
                Serial.println("file open failed");
            }

            //open_once = 0;

        //}

        i++;
       
        Serial.println("====== Writing to SPIFFS file =========");
        
        f.print(i);
        f.print(": ");
        f.print(sensor);
        f.print(", ");
        f.print(time_a);
        f.print(", ");
        f.print(lat, 6);
        f.print(", ");
        f.print(lon, 6);
        f.print(", ");
        f.println(data->RSSI);
        //f.print("\n");


        f.close(); 


        // open file for reading
        f = SPIFFS.open("/f.txt", "r");
        if (!f) {
            Serial.println("file open failed");
        }  
        Serial.println("====== Reading from SPIFFS file =======");
        // write 10 strings to file
       // for (int i=1; i<=4; i++){

        //while(f.available()) {
            //Lets read line by line from the file
            String line = f.readStringUntil('\n');
            Serial.println(line);
        //}   
        //    String s=f.readStringUntil('\n');
        //    Serial.print(i);
         //   Serial.print(":");
         //   Serial.println(s);
        //} 

       // f.close(); 


        // Print values.
        Serial.println("\n\r !!!FUCK!!! \n\r");

        Serial.println(sensor);
        Serial.println(time_a);
        Serial.println(lat, 6);
        Serial.println(lon, 6);

        Serial.println("\n\r !!!FUCK!!!END \n\r");


        //double lon = root2["data"][1];
        debug("SENSOR: %s", sensor);
        debug("TIME: %d", time_a);
        debug("%s", teste.c_str());
        patrick.concat("\n\rLAT: ");
        patrick.concat(String((root2["data"][0].as<float>()), 10));
        patrick.concat("\n\rLOT: ");
        patrick.concat(String((root2["data"][1].as<float>()), 10));
        patrick.concat("\n\r");
        debug("%s", patrick.c_str());
        debug("LATITUDE: %.2f", root2["data"][0].as<float>());
        debug("LATITUDE: %f", (root2["data"][0].as<float>()));
        debug("SIZE OF FLOAT: %d", sizeof(float));
        Serial.printf("LATITUDE: %f", (root2["data"][0].as<float>()));
        Serial.printf("LATITUDE: %d", lat*1e3);
        //debug("LONGITUDE: %d", lon);
        //data->upTime = root[0]["gps"][0].as<float>();
        //data->lat = root[0]["gps"][1].as<float>();
        //data->lon = root[0]["gps"][2].as<float>();

        //debug("success");
        //debug("LATITUDE = %f", root2[0]["gps"][0]);
        
        //float lat = root2[0]["data"][0];
        //float lat2 = root2[0]["gps"][0];

        //debug("%d", lat);
        //debug("%s", lat2);

        data->upTime = time_a;
        data->lat = lat;//root[0]["gps"][1].as<float>();
        data->lon = lon;//root[0]["gps"][2].as<float>();



    } else
        debug("Parsing failed");
}

// void Data::updateJson(uint8_t * msg){
//     StaticJsonBuffer<1024> jsonBuffer;
//     //debug("%s", msg.c_str());
//     root = &jsonBuffer.parseObject(msg);
//     debug("UINT MODE");
//     if(root->success()){
//         //debug("success");
//         debug("LATITUDE = %s", root[0]["gps"][1]);
//         data->upTime = root[0]["gps"][0].as<float>();
//         data->lat = root[0]["gps"][1].as<float>();
//         data->lon = root[0]["gps"][2].as<float>();
//     } else
//         debug("Parsing failed");
// }

void Data::print()
{

//    updateJson("{\"sensor\":\"gps\",\"time\":1351824120,\"data\":[\n30.756080,\n75.302038]}");


    updateJson();

    //Funciona de dentro da classe somente
    String string;
    string.concat("\n\rNetwork name : ");
    string.concat(data->networkName);
    string.concat("\n\rHost name : ");
    string.concat(data->hostName);
    string.concat("\n\rMAC address : ");
    string.concat(data->macAddress);
    string.concat("\n\rNetwork IP : ");
    string.concat(data->networkIP);

    string.concat("\n\rRSSI : ");
    string.concat(data->RSSI);
    string.concat(" dBm");

    string.concat("\n\rFree memory : ");
    string.concat(data->freeHeap);
    string.concat("\n\rupTime : ");
    string.concat(data->upTime);
    string.concat(" ms");

    debug("%s", string.c_str());
    root->prettyPrintTo(Serial);

    Serial.println("\n\r LOG FILE \n\r");
    Serial.println(data->RSSI);



    //String jsonData;
    //updateJson();
    //root->printTo(jsonData);
    //debug("%s", jsonData.c_str());
    //return jsonData;

    //debug("%s", jsonToString().c_str());

}

String Data::jsonToString()
{
    String jsonData;
    updateJson();
    root->printTo(jsonData);
    debug("%s", jsonData.c_str());
    return jsonData;
}

Data& Data::self()
{
    static Data self;
    return self;
}

Data::~Data()
{
}
