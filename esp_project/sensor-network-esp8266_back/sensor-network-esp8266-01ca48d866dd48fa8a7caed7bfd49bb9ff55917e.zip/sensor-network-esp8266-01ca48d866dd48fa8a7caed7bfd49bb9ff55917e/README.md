Sensor network with esp8266
---

Contributing
------------

1. Fork it.
2. Create a branch (`git checkout -b my_markup`)
3. Commit your changes (`git commit -am "Added something very cool"`)
4. Push to the branch (`git push origin my_markup`)
5. Open a [Pull Request][1]
6. Enjoy a good book and wait

`Code style: Kernighan & Ritchie`

[1]: https://github.com/Guiraffo/sensor-network-esp8266/pulls
