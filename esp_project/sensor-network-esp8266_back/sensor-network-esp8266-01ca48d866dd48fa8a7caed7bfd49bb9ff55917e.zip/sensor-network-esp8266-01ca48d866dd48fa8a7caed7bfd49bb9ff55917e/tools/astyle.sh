astyle --style=kr -R "${PWD}/*.ino" "${PWD}/*.cpp" "${PWD}/*.h"
